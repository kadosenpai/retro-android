package com.retro.app.data

/** Một cheat của một game. */
data class CheatItem(val id: String, val name: String, val code: String, val enabled: Boolean)

/**
 * Kiểm tra và chuẩn hoá mã cheat.
 * GBA: GameShark/Action Replay, mỗi dòng 12 hoặc 16 ký tự hex.
 * Game Boy/GBC: GameShark 8 ký tự hex (vd. 01FF16D1) hoặc Game Genie (XXX-XXX hoặc XXX-XXX-XXX).
 * NDS: Action Replay, các nhóm 8 ký tự hex (hai nhóm một dòng, vd. 94000130 FCFF0000).
 * SNES: Game Genie XXXX-XXXX (0-9, A-F) hoặc Pro Action Replay 8 ký tự hex (vd. 7E0DBE05).
 * NES: Game Genie 6 hoặc 8 chữ cái (APZLGITYEOXUKSVN), hoặc mã thô AAAA:VV / AAAA?CC:VV (hex).
 */
enum class CheatKind { GBA, GB, NES, SNES, NDS, MD, PSX }

object CheatCodes {
    private val nesGenie = Regex("^[APZLGITYEOXUKSVN]{6}([APZLGITYEOXUKSVN]{2})?$")
    private val nesRaw = Regex("^[0-9A-F]{4}(\\?[0-9A-F]{2})?:[0-9A-F]{2}$")

    private val snesGenie = Regex("^[0-9A-F]{4}-[0-9A-F]{4}$")
    private val snesPar = Regex("^[0-9A-F]{8}$")

    private val hex = Regex("^[0-9A-F]+$")
    private val gbGameShark = Regex("^[0-9A-F]{8}$")
    private val gbGenie = Regex("^[0-9A-F]{3}-[0-9A-F]{3}(-[0-9A-F]{3})?$")

    /** Trả về lỗi, hoặc null nếu hợp lệ. */
    fun validate(code: String, kind: CheatKind): String? = when (kind) {
        CheatKind.GB -> validateGb(code)
        CheatKind.NES -> validateNes(code)
        CheatKind.SNES -> validateSnes(code)
        CheatKind.NDS -> validateNds(code)
        CheatKind.MD -> validateMd(code)
        CheatKind.PSX -> validatePsx(code)
        CheatKind.GBA -> validateGba(code)
    }

    /** Dạng đưa vào lõi: viết hoa, các mã ngăn bằng dấu "+". */
    fun normalize(code: String, kind: CheatKind): String = when (kind) {
        CheatKind.GB -> gbTokens(code).joinToString("+")
        CheatKind.NES -> nesTokens(code).joinToString("+")
        CheatKind.SNES -> snesTokens(code).joinToString("+")
        CheatKind.NDS -> ndsTokens(code).joinToString("+")
        CheatKind.MD -> mdTokens(code).joinToString("+")
        CheatKind.PSX -> psxCodes(code).joinToString("+")
        CheatKind.GBA -> code.uppercase().replace('-', ' ').split(Regex("[\\s+]+")).filter { it.isNotEmpty() }.joinToString("+")
    }

    private fun nesTokens(code: String): List<String> =
        code.uppercase().split(Regex("[\\s+,;]+")).filter { it.isNotEmpty() }

    private fun validateNes(code: String): String? {
        val tokens = nesTokens(code)
        if (tokens.isEmpty()) return "Chưa nhập mã"
        for (t in tokens) {
            if (!nesGenie.matches(t) && !nesRaw.matches(t)) {
                return "Mã NES: Game Genie 6 hoặc 8 chữ cái (vd. SXIOPO) hoặc mã thô dạng 0075:09"
            }
        }
        return null
    }

    /** Tách thành từng mã; Game Genie viết liền 8 ký tự hex thì giữ nguyên là mã PAR (hai loại không phân biệt được khi viết liền, nên Game Genie phải có dấu gạch). */
    private fun snesTokens(code: String): List<String> =
        code.uppercase().split(Regex("[\\s+,;]+")).filter { it.isNotEmpty() }

    private fun validateSnes(code: String): String? {
        val tokens = snesTokens(code)
        if (tokens.isEmpty()) return "Chưa nhập mã"
        for (t in tokens) {
            if (!snesGenie.matches(t) && !snesPar.matches(t)) {
                return "Mã SNES: Game Genie XXXX-XXXX (có dấu gạch) hoặc Pro Action Replay 8 ký tự (vd. 7E0DBE05)"
            }
        }
        return null
    }

    /** Mã Action Replay NDS: các nhóm 8 ký tự hex, tổng số nhóm chẵn (mỗi lệnh gồm hai nhóm). */
    private fun ndsTokens(code: String): List<String> =
        code.uppercase().split(Regex("[\\s+,;-]+")).filter { it.isNotEmpty() }

    private fun validateNds(code: String): String? {
        val tokens = ndsTokens(code)
        if (tokens.isEmpty()) return "Chưa nhập mã"
        for (t in tokens) {
            if (!snesPar.matches(t)) return "Mã NDS: các nhóm 8 ký tự hex (0-9, A-F), vd. 94000130 FCFF0000"
        }
        if (tokens.size % 2 != 0) return "Mã NDS gồm từng cặp hai nhóm 8 ký tự; đang thiếu một nhóm"
        return null
    }

    private val mdGenie = Regex("^[A-Z0-9]{4}-[A-Z0-9]{4}$")
    private val mdPar = Regex("^[0-9A-F]{6}:[0-9A-F]{4}$")

    private fun mdTokens(code: String): List<String> =
        code.uppercase().split(Regex("[\\s+,;]+")).filter { it.isNotEmpty() }

    private fun validateMd(code: String): String? {
        val tokens = mdTokens(code)
        if (tokens.isEmpty()) return "Chưa nhập mã"
        for (t in tokens) {
            if (!mdGenie.matches(t) && !mdPar.matches(t)) {
                return "Mã Mega Drive: Game Genie XXXX-XXXX hoặc Pro Action Replay XXXXXX:XXXX"
            }
        }
        return null
    }

    /** Mã GameShark PlayStation: từng cặp "8 ký tự hex" + "4 ký tự hex"; trả về danh sách "AAAAAAAA BBBB". */
    private fun psxTokens(code: String): List<String> =
        code.uppercase().split(Regex("[\\s+,;:-]+")).filter { it.isNotEmpty() }

    private fun psxCodes(code: String): List<String> =
        psxTokens(code).chunked(2).map { it.joinToString(" ") }

    private fun validatePsx(code: String): String? {
        val tokens = psxTokens(code)
        if (tokens.isEmpty()) return "Chưa nhập mã"
        if (tokens.size % 2 != 0) return "Mã PlayStation gồm từng cặp: 8 ký tự hex rồi 4 ký tự hex (vd. 800A1234 00FF)"
        for ((i, t) in tokens.withIndex()) {
            val len = if (i % 2 == 0) 8 else 4
            if (t.length != len || !hex.matches(t)) return "Mã PlayStation gồm từng cặp: 8 ký tự hex rồi 4 ký tự hex (vd. 800A1234 00FF)"
        }
        return null
    }

    private fun validateGba(code: String): String? {
        val lines = code.uppercase()
            .split(Regex("[\n+]+"))
            .map { it.replace(Regex("[\\s-]+"), "") }
            .filter { it.isNotEmpty() }
        if (lines.isEmpty()) return "Chưa nhập mã"
        for (l in lines) {
            if (!hex.matches(l)) return "Mã chỉ gồm chữ số 0-9 và chữ A-F"
            if (l.length != 12 && l.length != 16) return "Mỗi dòng mã phải đủ 12 hoặc 16 ký tự (tính cả hai nhóm)"
        }
        return null
    }

    /** Tách thành từng mã; Game Genie viết liền 6 hoặc 9 ký tự thì tự thêm dấu gạch. */
    private fun gbTokens(code: String): List<String> =
        code.uppercase().split(Regex("[\\s+,]+")).filter { it.isNotEmpty() }.map { t ->
            when {
                hex.matches(t) && t.length == 6 -> t.substring(0, 3) + "-" + t.substring(3)
                hex.matches(t) && t.length == 9 -> t.substring(0, 3) + "-" + t.substring(3, 6) + "-" + t.substring(6)
                else -> t
            }
        }

    private fun validateGb(code: String): String? {
        val tokens = gbTokens(code)
        if (tokens.isEmpty()) return "Chưa nhập mã"
        for (t in tokens) {
            if (!gbGameShark.matches(t) && !gbGenie.matches(t)) {
                return "Mã Game Boy: GameShark 8 ký tự (vd. 01FF16D1) hoặc Game Genie (XXX-XXX-XXX)"
            }
        }
        return null
    }
}
